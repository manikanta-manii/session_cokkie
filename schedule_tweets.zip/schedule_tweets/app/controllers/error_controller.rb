class ErrorController < ApplicationController
    def index
    end
end