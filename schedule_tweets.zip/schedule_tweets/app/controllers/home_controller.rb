class HomeController < ApplicationController
    def index
        flash[:notice] = "Login Successfull"
        if session[:user_id]
            @user=User.find_by(id: session[:user_id])
        end
        if session[:user_email]
            @user_email=session[:user_email]
        end
    end
end