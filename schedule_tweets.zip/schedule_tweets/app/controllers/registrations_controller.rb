class RegistrationsController < ApplicationController
    def new
        @user = User.new
    end
    def create
         @user = User.new(user_params)
         if @user.save
          #set cokkie to track the user being signed in
          #session cokkie -- cokkie saved in browser but its encrypted and cant be tamper 
          session[:user_id]=@user.id
          redirect_to root_path # Redirect to the homepage or any other appropriate path
        else
            flash[:alert] = "Invalid"
           
            puts "invalid"
            redirect_to sign_up_path
       
        # Render the form again with errors if saving fails
        end
      end 

    
      private   
      def user_params
        params.require(:user).permit(:email, :password, :password_confirmation)
      end


end
