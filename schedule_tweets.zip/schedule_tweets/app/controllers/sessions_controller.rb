class SessionsController < ApplicationController
    def destroy
        session[:user_id]=nil
        redirect_to root_path, notice: "Logged Out"
    end
    def new
        
    end
    def create
       user = User.find_by(email: params[:email])
       p user
       if(user.present? && user.authenticate(params[:password]))
         redirect_to root_path , notice: "SIGNED IN SUCCESSfull"
         session[:user_email]=user.email
         p user.email
       else
        flash[:alert] = "Invalid"
        redirect_to sign_in_path
       end
    end
end